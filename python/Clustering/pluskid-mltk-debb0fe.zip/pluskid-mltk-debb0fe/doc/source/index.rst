mltk
====

mltk is **M**\ achine **L**\ earning **T**\ ool\ **k**\ it for Python.

Contents:

.. toctree::
    :maxdepth: 2

Reference
=========

.. toctree::
    :maxdepth: 1

    cluster

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

